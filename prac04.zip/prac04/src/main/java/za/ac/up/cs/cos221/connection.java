
package za.ac.up.cs.cos221;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;

import java.io.File;  
import java.io.FileNotFoundException;  
import java.util.Scanner;


public class connection {
    private static Connection con;
    public connection()throws SQLException{
        System.out.println("Connecting to database...");
       /* String DBLocation = "jdbc:mariadb://127.0.0.1:3306/u21669831_sakila";
        String user = "root";
        String pass = "";*/
        String SAKILA_DB_HOST = "127.0.0.1";
        String SAKILA_DB_PORT = "3306";
        String SAKILA_DB_NAME = "u21669831_sakila";
        String SAKILA_DB_USERNAME = "root";
        String SAKILA_DB_PASSWORD = "Bianc@9854";
        String SAKILA_DB_PROTO = "jdbc:mariadb://" + SAKILA_DB_HOST + ":" + SAKILA_DB_PORT + "/" + SAKILA_DB_NAME;
        con = DriverManager.getConnection(SAKILA_DB_PROTO, SAKILA_DB_USERNAME, SAKILA_DB_PASSWORD);
        System.out.println("Connection valid: " + con.isValid(5));
    }
    
    public Connection openConnection()throws SQLException{
        return con;
    }
    
    public static void closeCon() throws SQLException{
        System.out.println("Closing DB conection");
        con.close();
    }
    
}
